# Prioritized Backlog

## P0 — Repository and recovery

- Download the exact original `review.html` from ChatGPT File Library and commit it under `legacy/original-review.html`.
- Compare original behavior with this reconstructed baseline.
- Preserve any useful original dataset that is not yet in `data/posts.json`.
- Confirm current deployment ownership and configuration.

## P0 — Shared production application

- Add authentication and roles.
- Replace JSON storage with PostgreSQL.
- Add migrations and sanitized seed data.
- Add safe concurrent review.
- Add audit history in the UI.
- Deploy one shared environment.

## P0 — Full media analysis

- Retrieve all carousel children.
- Retrieve playable video where authorized.
- Add scene-aware frame extraction.
- Add audio extraction and transcription.
- Add OCR.
- Store timestamped evidence.
- Add completeness flags.
- Route incomplete media to review.

## P1 — Data and classification

- Import the complete June dataset.
- Preserve post/comment separation.
- Add legacy product taxonomy.
- Add evaluation fixtures.
- Measure precision, recall and review rate.
- Keep prompts and rules versioned.

## P1 — Review UI

- Show all carousel children.
- Show video frames and transcript.
- Add broken-link status.
- Add explicit Needs Review reason filters.
- Add review claiming/locking.
- Add history and reopen controls.

## P1 — Scraping operations

- Named scrape runs.
- Exact date boundaries and timezone.
- Retry and duplicate tracking.
- Rate-limit logging.
- Failure reports.
- Reproducible June run.

## P2 — Engineering operations

- CI.
- tests.
- background queue monitoring.
- error tracking.
- cost dashboard.
- media retention policy.
- deployment rollback.
