---
name: Classification error
about: Incorrect or uncertain content classification
title: ""
labels: ""
assignees: ""
---

## Content reference

## Expected result

## Actual result

## Evidence available

- Caption:
- Hashtags:
- Mentions:
- Visual:
- Audio:
- On-screen text:
- Account context:

## Why it is wrong

## Proposed test case or rule
