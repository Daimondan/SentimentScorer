# Original Artifact

The original generated application is a large single file named `review.html`, created July 15, 2026 in the owner’s ChatGPT File Library.

Live deployment:

`https://sentiment-scorer-aa.gizzle.chatgpt.site/`

The current package could not automatically copy the full File Library artifact byte-for-byte. After the owner downloads it, commit it here as:

`legacy/original-review.html`

Then compare it with the reconstructed baseline before removing or replacing any behavior.
